(function($){
    "use strict";
    
    var wWidth = $(window).width();
      var clipboard = new Clipboard('.copy-btn');
        
        $('.copy-btn').on('click',function(e){
            e.target.innerHTML = 'copied';
           $(e.target).css('background','#7AC943');
        }).on('mouseleave',function(e){
            e.target.innerHTML = 'copy';
            $(e.target).css('background','#5BBC2E');
        });
//        var firstLabel = $('.sidebar-nav li');
//        var secondLabel = $('.sidebar-nav li ul li');
//        firstLabel.on('click',function(ev){
//            ev.preventDefault();
//            $(this).addClass('active');
//            $(this).siblings('li').removeClass('active');
//
//        });
//    secondLabel.on('click',function(ev){
//        ev.preventDefault();
//        $(this).addClass('active');
//        $(this).parent()
//
//    });
    
    //$('.banner-info-area .btn-xld').();
    
//    $(window).on('load',function() {
//          $('.code-area').css({'overflow':'hidden'});
//    });
//    $('.code-area').on('mouseenter',function(){
//        $(this).css({'overflow':'auto'});
//    }).on('mouseleave',function(){
//        $(this).css({'overflow':'hidden'});
//    });
    
//    var actulClick = $('.sidebar-left').find('li');
//    actulClick.on('click',function(){
//        alert('testing');
//    });
    
    $(window).on('scroll',function(){
        if($(this).scrollTop() > 50){
            //$('.inner_header').addClass('menuExpand');
            $('.common-searchbox').not('.header_search,.mobile_searchbox').css({
                "visibility":"hidden",
                "overflow":"hidden"
            });
        }
        else{
            $('.common-searchbox').not('.header_search,.mobile_searchbox').css({
                "visibility":"visible",
                "overflow":"initial"
            });
        }
        if($(this).scrollTop() >70){
            $('.inner_header').addClass('menuExpand');
//            $('.common-searchbox.header_search').css({
//                "visibility":"visible",
//                "opacity":"1",
//                "width":"35%"
//            });
            $('.common-searchbox.header_search').addClass('expand');
        }
        else{
            
            $('.inner_header').removeClass('menuExpand');
//            $('.common-searchbox.header_search').css({
//                "visibility":"hidden",
//                "opacity":"0",
//                "width":"0%"
//            });
             $('.common-searchbox.header_search').removeClass('expand');
        }
    });
     $('.common-searchbox .field-control').focus();
    jQuery(window).ready(function($){
      // Get current path and find target link
      var path = window.location.pathname.split("/").pop();

      // Account for home page with empty path
      if ( path == '' ) {
        path = 'index.php';
      }

      var target = $('.sidebar-left-inner a[href="'+path+'"]');
      // Add active class to target link
      target.addClass('active');
       
        target.parents('ul').siblings('a').addClass('innerParent');
        target.css({
            "color":"#5BBC2E"
        });
    });
    
    $('.preview_menu_toggle').click(function(){
        var bClass = $(document).find('.off-show');
        $('body').addClass('menuActive');
        $('body').css({
               "height":"100vh",
               "overflow":"hidden"
           });
        $('.offcanvas-overlay').css({
               "height":"100vh",
               "overflow":"hidden"
           });
    });
       $(document).mouseup(function (e) {
        var container = $(".preview_menu_toggle,.offcanvas");
        if (!container.is(e.target) && container.has(e.target).length === 0) {
            $('body').removeAttr('style');
            $('.offcanvas-overlay').remove();
        }

    });
    $('.offcanvas-overlay').on('click', function () {
        $('body').removeAttr("style");
        $('.offcanvas-overlay').remove();
    });
//    function FocusOnInput()
//{
//     document.getElementById("InputID").focus();
//}
  
//    if(wWidth <= 767){
//       function disable(){
//       $('.offcanvas-overlay').on("mousewheel", function() {
//            return false;
//        });
//        }
//        disable();
//    }
//    

//   $(document).on('click',function(e){
//       if($('body').hasClass('off-show')){
//           $('.offcanvas-overlay').on('click',function(){
//               $(this).stopPropagation();
//               alert('test');
//           });
//           
//       }
//       else{
//               alert('not');
//           }
//   });
    
    
    
    $(".common-searchbox input").each(function(){
      
        $(this).on('keyup',function(){
            if($(this).siblings('ul').children('li').length > 0){
               $(this).siblings('ul').addClass('show_me');
            }
            else{
                $(this).siblings('ul').removeClass('show_me');
            }
        });
        $(this).on('keydown',function (e){
            if(e.keyCode == 13){
                e.preventDefault();
               if($(this).siblings('ul').children('li').length > 0){
                   var url = $(this).siblings('ul').children('li').first('li').children('a').attr('href');
                   window.location = url;
                   
                }
            }
        })
        
    });
    
    //You tybe video
    $(".video_btn").on("click", function () {　
        var overlay = $('.overlay');
        videoControl("playVideo");
        $(".bg_holder").hide();
        //$('.video-inner-area .overlay').addClass('tong');
        $(this).parents('.video-inner-area').find(overlay).hide();
        $(this).hide();
    });

    function videoControl(action) {
        var $playerWindow = $('.frame_video')[0].contentWindow;
        $playerWindow.postMessage('{"event":"command","func":"' + action + '","args":""}', '*');
    }
    $('.offra_reply').on('click',function(){
        var cChild = $('.offra-commnet-list').find('.real_comment_child');
        $(this).parents('.offra-comment').siblings('.real_comment_child').slideToggle();
        
    });
    
   var iOS = !!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform);
   if (iOS) {
      $('.preview_menu_toggle').click(function () {
           var bClass = "<div class='offcanvas-cancel'>X</div>";
           $('.offcanvas').prepend(bClass);
           $('body').on('click', function (e) {
               var targetClass = ($(e.target).attr('class'));
               if (targetClass === 'offcanvas-cancel') {
                   $('body').removeClass('off-show');
                   $('.offcanvas').removeClass('show');
                   $(".offcanvas-overlay").remove();
                   $('body').removeAttr("style");

               }

           });
       });

   } else {
//       $('.preview_menu_toggle').click(function () {
//           var bClass = "<div class='offcanvas-cancel'>X</div>";
//           $('.offcanvas').prepend(bClass);
//           $('body').on('click', function (e) {
//               var targetClass = ($(e.target).attr('class'));
//               if (targetClass === 'offcanvas-cancel') {
//                   $('body').removeClass('off-show');
//                   $('.offcanvas').removeClass('show');
//                   $(".offcanvas-overlay").remove();
//                   $('body').removeAttr("style");
//
//               }
//
//           });
//       });
   }
   
   
    
})(jQuery)